package org.apache.hadoop.hdfs.server.blockmanagement;

import java.util.*;
import java.util.stream.Collectors;
import java.util.concurrent.ThreadLocalRandom;

/**
 * WeightSelectionHelper
 *
 * Implements the core ANODE probabilistic selection:
 * - Given a map of host -> weight (Pi normalized), select k distinct hosts
 *   using weighted random sampling without replacement (roulette-wheel).
 *
 * This helper is intentionally independent of Hadoop APIs so it can be unit-tested.
 */
public class WeightSelectionHelper {

    /**
     * Select k distinct hosts from candidates using weights map (host -> weight).
     * We perform sampling without replacement:
     * - At each selection, perform weighted choice among remaining candidates.
     *
     * @param candidates list of candidate hostnames (must be keys in weights)
     * @param weights map of hostname -> weight (weights need not sum to 1)
     * @param k number of hosts to select
     * @return list of selected hostnames (size <= k if not enough candidates)
     */
    public static List<String> selectHosts(List<String> candidates, Map<String, Double> weights, int k) {
        if (candidates == null) return Collections.emptyList();
        if (weights == null) weights = Collections.emptyMap();
        // Filter candidates present in weights; if none, treat equal weights.
        List<String> pool = candidates.stream().filter(Objects::nonNull).collect(Collectors.toList());
        if (pool.isEmpty()) return Collections.emptyList();
        Map<String, Double> w = new HashMap<>();
        double total = 0.0;
        for (String c : pool) {
            double val = weights.getOrDefault(c, 0.0);
            // treat non-positive weights as small epsilon to still allow selection
            if (val <= 0.0) val = 1e-9;
            w.put(c, val);
            total += val;
        }
        // If total is zero (all weights zero), set uniform weights
        if (total == 0.0) {
            for (String c : pool) {
                w.put(c, 1.0);
            }
            total = pool.size();
        }

        List<String> result = new ArrayList<>();
        Set<String> chosen = new HashSet<>();
        int toChoose = Math.min(k, pool.size());
        for (int i = 0; i < toChoose; i++) {
            double r = ThreadLocalRandom.current().nextDouble(0.0, total);
            double acc = 0.0;
            String pick = null;
            for (String c : pool) {
                if (chosen.contains(c)) continue;
                acc += w.getOrDefault(c, 0.0);
                if (r <= acc) {
                    pick = c;
                    break;
                }
            }
            // fallback: choose first not chosen
            if (pick == null) {
                for (String c: pool) {
                    if (!chosen.contains(c)) { pick = c; break; }
                }
            }
            if (pick == null) break;
            result.add(pick);
            chosen.add(pick);
            // subtract its weight from total so remaining selection works
            total -= w.getOrDefault(pick, 0.0);
        }
        return result;
    }
}
