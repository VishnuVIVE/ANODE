package org.apache.hadoop.hdfs.server.blockmanagement;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hdfs.server.blockmanagement.BlockPlacementPolicyDefault;
import org.apache.hadoop.hdfs.server.blockmanagement.DatanodeDescriptor;
import org.apache.hadoop.hdfs.server.blockmanagement.FSClusterStats;
import org.apache.hadoop.hdfs.server.blockmanagement.Host2NodesMap;
import org.apache.hadoop.net.NetworkTopology;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FSDataInputStream;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PerformanceAwareBlockPlacementPolicy
 *
 * This class integrates ANODE's weight-driven selection into Hadoop's block placement.
 * It delegates the core selection algorithm to WeightSelectionHelper, which is unit-testable.
 *
 * Note: The Hadoop integration here is illustrative: production deployment must thoroughly
 * test selection against the actual cluster and ensure thread-safety and correctness.
 */
public class PerformanceAwareBlockPlacementPolicy extends BlockPlacementPolicyDefault {
    private static final Logger LOG = LoggerFactory.getLogger(PerformanceAwareBlockPlacementPolicy.class);
    private Map<String, Double> nodeWeights = new HashMap<>();
    private boolean weightedEnabled = true;
    private Configuration conf;

    public PerformanceAwareBlockPlacementPolicy() {
        super();
    }

    @Override
    public void initialize(Configuration conf, FSClusterStats fsStats,
                           Host2NodesMap host2DatanodeMap,
                           NetworkTopology clusterMap,
                           DatanodeDescriptor[] excludedNodes) {
        super.initialize(conf, fsStats, host2DatanodeMap, clusterMap, excludedNodes);
        this.conf = conf;
        this.weightedEnabled = conf.getBoolean("dfs.blockplacement.weighted.enabled", true);
        loadWeightsFromConfig();
    }

    private void loadWeightsFromConfig() {
        String weightsPath = conf.get("dfs.anode.weights.file", null);
        if (weightsPath != null) {
            try {
                FileSystem fs = FileSystem.get(conf);
                Path p = new Path(weightsPath);
                if (fs.exists(p)) {
                    try (FSDataInputStream in = fs.open(p)) {
                        // TODO: parse XML and populate nodeWeights map.
                        // Implement XML parsing and populate nodeWeights.
                    }
                }
            } catch (Exception e) {
                LOG.warn("Failed to read ANODE weights file: " + e.getMessage());
            }
        }
        if (nodeWeights.isEmpty()) {
            String raw = conf.get("dfs.datanode.data.dir.weight", "");
            parseInlineWeights(raw);
        }
    }

    private void parseInlineWeights(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String[] pairs = raw.split(",");
        for (String p : pairs) {
            String[] kv = p.split(":");
            if (kv.length == 2) {
                try {
                    nodeWeights.put(kv[0].trim(), Double.parseDouble(kv[1].trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /**
     * chooseTarget - simplified override that selects a single DatanodeDescriptor based on weights.
     * For full multi-replica placement, extend to choose multiple targets using WeightSelectionHelper.
     */
    @Override
    public DatanodeDescriptor chooseTarget(String srcPath, int numOfReplicas,
                                          DatanodeDescriptor writer, List<DatanodeDescriptor> chosen,
                                          boolean returnChosenNodes) {
        if (!weightedEnabled || nodeWeights.isEmpty()) {
            return super.chooseTarget(srcPath, numOfReplicas, writer, chosen, returnChosenNodes);
        }

        // Build candidate host list from cluster's datanodes known to this policy.
        List<DatanodeDescriptor> available = new ArrayList<>(this.host2DatanodeMap.getAllDatanodes());
        // Filter out already chosen nodes and writer
        List<DatanodeDescriptor> candidates = new ArrayList<>();
        for (DatanodeDescriptor d : available) {
            if (chosen != null && chosen.contains(d)) continue;
            if (writer != null && writer.equals(d)) continue;
            candidates.add(d);
        }

        if (candidates.isEmpty()) {
            return super.chooseTarget(srcPath, numOfReplicas, writer, chosen, returnChosenNodes);
        }

        // Map hostnames to weights expected by helper
        Map<String, Double> weights = new HashMap<>();
        for (DatanodeDescriptor d : candidates) {
            String host = d.getHostName();
            double w = nodeWeights.getOrDefault(host, 0.0);
            weights.put(host, w);
        }

        // Select one host for this chooseTarget call (for multi-replica placement, loop selections)
        List<String> hostCandidates = new ArrayList<>();
        for (DatanodeDescriptor d : candidates) hostCandidates.add(d.getHostName());

        List<String> selected = WeightSelectionHelper.selectHosts(hostCandidates, weights, 1);
        if (selected.isEmpty()) {
            return super.chooseTarget(srcPath, numOfReplicas, writer, chosen, returnChosenNodes);
        }
        String selHost = selected.get(0);
        for (DatanodeDescriptor d : candidates) {
            if (d.getHostName().equals(selHost)) return d;
        }
        return super.chooseTarget(srcPath, numOfReplicas, writer, chosen, returnChosenNodes);
    }

    public void refreshWeights(Map<String, Double> newWeights) {
        this.nodeWeights.clear();
        this.nodeWeights.putAll(newWeights);
    }
}
