package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.apache.hadoop.hdfs.server.blockmanagement.WeightSelectionHelper;

public class WeightSelectionHelperTest {

    @Test
    public void testUniformWeightsSelection() {
        List<String> candidates = Arrays.asList("n1","n2","n3","n4");
        Map<String, Double> weights = new HashMap<>();
        // equal weights
        weights.put("n1", 1.0); weights.put("n2", 1.0); weights.put("n3", 1.0); weights.put("n4",1.0);
        List<String> sel = WeightSelectionHelper.selectHosts(candidates, weights, 2);
        assertEquals(2, sel.size());
        assertNotEquals(sel.get(0), sel.get(1));
        assertTrue(candidates.containsAll(sel));
    }

    @Test
    public void testWeightedPreference() {
        List<String> candidates = Arrays.asList("fast","slow");
        Map<String, Double> weights = new HashMap<>();
        weights.put("fast", 100.0);
        weights.put("slow", 1.0);
        // call multiple times to ensure 'fast' is usually chosen
        int fastCount = 0;
        int trials = 200;
        for (int i=0;i<trials;i++) {
            List<String> sel = WeightSelectionHelper.selectHosts(candidates, weights, 1);
            if (sel.size()>0 && sel.get(0).equals("fast")) fastCount++;
        }
        // Expect fast chosen most of the time (say >85% of trials)
        assertTrue(fastCount > trials*0.85);
    }

    @Test
    public void testRequestMoreThanAvailable() {
        List<String> candidates = Arrays.asList("a","b");
        Map<String, Double> weights = new HashMap<>();
        weights.put("a", 1.0); weights.put("b", 1.0);
        List<String> sel = WeightSelectionHelper.selectHosts(candidates, weights, 5);
        assertEquals(2, sel.size());
        assertTrue(sel.contains("a") && sel.contains("b"));
    }
}
