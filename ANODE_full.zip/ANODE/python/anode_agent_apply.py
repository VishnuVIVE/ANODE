#!/usr/bin/env python3
"""Upload ANODE weights XML to HDFS, update hdfs-site.xml properties, and trigger reconfig.

Usage:
  python anode_agent_apply.py --weights /tmp/WordCount.xml --hdfs-dest /user/hadoop/anode/weights/WordCount.xml --hdfs-site /etc/hadoop/conf/hdfs-site.xml
"""
import argparse
import subprocess
import xml.etree.ElementTree as ET

def hdfs_put(local, hdfs_path):
    cmd = ["hdfs", "dfs", "-put", "-f", local, hdfs_path]
    subprocess.check_call(cmd)

def update_hdfs_site_property(hdfs_site_path, prop_name, prop_value):
    tree = ET.parse(hdfs_site_path)
    root = tree.getroot()
    for prop in root.findall('property'):
        name = prop.find('name')
        if name is not None and name.text == prop_name:
            val = prop.find('value')
            if val is None:
                val = ET.SubElement(prop, 'value')
            val.text = prop_value
            tree.write(hdfs_site_path, xml_declaration=True, encoding='utf-8')
            return
    p = ET.SubElement(root, 'property')
    n = ET.SubElement(p, 'name'); n.text = prop_name
    v = ET.SubElement(p, 'value'); v.text = prop_value
    tree.write(hdfs_site_path, xml_declaration=True, encoding='utf-8')

def run_reconfig():
    cmd = ["hdfs", "dfsadmin", "-reconfig"]
    subprocess.check_call(cmd)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', required=True)
    parser.add_argument('--hdfs-dest', required=True)
    parser.add_argument('--hdfs-site', default='/etc/hadoop/conf/hdfs-site.xml')
    args = parser.parse_args()

    hdfs_put(args.weights, args.hdfs_dest)

    update_hdfs_site_property(args.hdfs_site, 'dfs.anode.weights.file', args.hdfs_dest)

    tree = ET.parse(args.weights)
    root = tree.getroot()
    pairs = []
    for node in root.findall('node'):
        name = node.get('name')
        weight = node.get('weight')
        if name and weight:
            pairs.append(f"{name}:{weight}")
    inline_val = ",".join(pairs)
    update_hdfs_site_property(args.hdfs_site, 'dfs.datanode.data.dir.weight', inline_val)

    try:
        run_reconfig()
        print("Reconfig triggered.")
    except subprocess.CalledProcessError as e:
        print("Reconfig failed; you may need to restart NameNode. Error:", e)

if __name__ == '__main__':
    main()
